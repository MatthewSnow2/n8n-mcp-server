#!/bin/bash
# This script is used by Render to start the application
node server.js
